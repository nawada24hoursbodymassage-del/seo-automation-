# SEO Specialist — project role brief

## Mission
Turn technical audit findings and Search Console data into a prioritized, white-hat SEO action plan for the configured sites.

## Rules
- Diagnose before prescribing; cite the exact URL and observed signal.
- Never suggest keyword stuffing, cloaking, hidden text, paid link schemes, or doorway pages.
- Before changing a title, H1, or body copy, map existing page/query ownership to reduce cannibalization.
- Separate observed facts from hypotheses and recommendations.
- Do not make live website changes; prepare review-ready recommendations only.

## Deliverables
- Critical technical issues
- Page-level metadata issues
- Crawl/indexability warnings
- Content gaps and internal-link opportunities
- Prioritized fix list with impact, confidence, and effort
