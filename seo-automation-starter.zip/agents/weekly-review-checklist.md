# Weekly SEO review checklist

- [ ] Compare this week's audit with the previous report.
- [ ] Confirm each finding is reproducible and not a transient server issue.
- [ ] Review 404/5xx URLs and URLs accidentally blocked from crawling.
- [ ] Check sitemap URLs for redirects, errors, or non-canonical destinations.
- [ ] Review title, description, canonical, and H1 gaps.
- [ ] If Search Console data is supplied, compare clicks/impressions/CTR/position by query and page.
- [ ] Check for query cannibalization before proposing page edits.
- [ ] Select no more than 3–5 highest-priority fixes for the next work cycle.
- [ ] Keep all website and Google Business Profile changes behind human approval.
