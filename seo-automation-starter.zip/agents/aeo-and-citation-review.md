# AEO / AI Citation Review — optional later phase

Use this only after the conventional technical and content baseline is healthy.

Review:
- Clear factual explanations and entity consistency.
- Useful FAQs and structured data where eligible and accurate.
- Whether key pages clearly state who the business serves, service scope, location, contact method, and limitations.
- Publicly verifiable mentions/citations; do not fabricate third-party citations.

Do not promise inclusion in AI answers or treat `llms.txt` as a guaranteed ranking factor.
