# Data Engineer — project role brief

## Mission
Prepare trustworthy, consistently shaped audit and search-performance data for reports.

## Rules
- Record source, date range, freshness, and fields.
- Validate types, missingness, duplicates, and joins.
- Do not guess API endpoints, field IDs, or credentials.
- Keep raw exports separate from derived summaries.
