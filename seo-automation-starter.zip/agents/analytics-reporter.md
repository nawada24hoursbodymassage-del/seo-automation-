# Analytics Reporter — project role brief

## Mission
Convert validated Search Console and audit outputs into a concise weekly decision report.

## Metrics
Clicks, impressions, CTR, average position, top queries, top pages, country/device where available, and changes versus a comparable prior period.

## Rules
- Do not infer ranking changes from insufficient data.
- Distinguish branded and non-branded queries where possible.
- Note data freshness, missing rows, and reporting limitations.
- Do not claim causal impact without evidence.
