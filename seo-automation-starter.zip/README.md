# SEO Automation Starter

Starter kit for automated, read-only SEO checks for:
- https://awesomespadelhi.com
- https://escortservicesdelhi.com

This project adapts a workflow around three roles from the `agency-agents` project (SEO Specialist, DevOps Automator, Analytics Reporter), with supporting roles for content and data handling. It does **not** install those agents into ChatGPT or copy their original prompt files. It provides a practical workflow and original role briefs.

## What it does now
- Runs a daily technical SEO audit with GitHub Actions.
- Checks `robots.txt` and sitemap reachability.
- Reads sitemap URLs and crawls a configurable number of pages.
- Checks HTTP status, title, meta description, canonical, H1, and indexability signals.
- Creates Markdown and CSV reports and uploads them as workflow artifacts.
- Does not change your live website or Google Business Profile.

## What it does not do yet
- Does not yet pull Search Console or Google Business Profile data automatically.
- Does not publish content, edit pages, create backlinks, or change GBP listings.
- Does not guarantee ranking gains. Audit findings need review and prioritization.

## Setup
1. Create a **private** GitHub repository named `seo-automation`.
2. Upload/extract all files from this starter kit into the repository root.
3. In GitHub, open **Actions** and enable workflows if prompted.
4. Open **Actions → Daily SEO Audit → Run workflow** to test manually.
5. The schedule is 02:30 UTC daily (08:00 India Standard Time). GitHub scheduled jobs can occasionally start late.
6. Download the `seo-audit-report` artifact from each run.

## Configuration
Edit `config/sites.json` to add/remove sites or change `max_urls_per_site` (default 100).
The crawler uses a descriptive user-agent and a modest delay. Keep the limit conservative and respect each site's robots policy and server capacity.

## GitHub Actions permissions and secrets
The current workflow only needs read access to the repo and permission to upload an artifact. No API secrets are required for the technical audit.

For future Search Console/Windsor.ai integration:
- Prefer Windsor.ai's supported scheduled export to a controlled destination, or use a documented API with a supported auth method.
- Store tokens/credentials in GitHub **Settings → Secrets and variables → Actions**.
- Never commit secrets to this repository or paste them into chat.
- Confirm the precise Windsor.ai endpoint, authentication method, and field IDs before implementing an API client.

## Agent roles used in this workflow
- **SEO Specialist** — decides which issues matter and prevents keyword cannibalization.
- **DevOps Automator** — maintains scheduled runs, failure handling, and artifacts.
- **Analytics Reporter** — summarizes trends and prioritizes fixes.
- **Content Creator** — drafts content only after intent and existing page ownership are checked.
- **Data Engineer** — prepares validated data inputs for later reporting.
- **AEO Foundations / AI Citation Strategist** — optional later-stage discovery and citation research, not a replacement for conventional SEO.

## Suggested operating loop
1. Daily: technical checks.
2. Weekly: review audit deltas and Search Console export.
3. Before any title/H1/content change: map the target query to existing pages to avoid cannibalization.
4. Human review: approve changes before publishing.
5. GBP: monitor profile completeness and review/post ideas separately; no automatic changes in this starter kit.

## Folder layout
- `seo_audit.py` — read-only crawler and report generator.
- `config/sites.json` — target domains and crawl limit.
- `.github/workflows/daily-seo-audit.yml` — scheduled workflow.
- `agents/` — original role briefs and review checklist.
- `reports/` — local output folder (workflow artifact is the persistent output).
