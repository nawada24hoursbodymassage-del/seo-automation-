#!/usr/bin/env python3
"""Read-only, polite technical SEO audit. Outputs CSV and Markdown reports."""
import argparse, csv, json, os, re, time
from collections import Counter, deque
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse, urldefrag
import requests
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET

def clean_url(url):
    url, _ = urldefrag(url.strip())
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.netloc:
        return None
    return url

def same_host(a, b):
    return urlparse(a).netloc.lower().removeprefix("www.") == urlparse(b).netloc.lower().removeprefix("www.")

def get(session, url, timeout):
    try:
        return session.get(url, timeout=timeout, allow_redirects=True)
    except requests.RequestException as e:
        return e

def sitemap_urls(session, sitemap, timeout, max_urls, seen=None):
    seen = seen or set()
    urls = []
    if sitemap in seen:
        return urls
    seen.add(sitemap)
    r = get(session, sitemap, timeout)
    if isinstance(r, Exception) or r.status_code >= 400:
        return urls
    try:
        root = ET.fromstring(r.content)
    except ET.ParseError:
        return urls
    tag = root.tag.lower()
    locs = [el.text.strip() for el in root.iter() if el.tag.lower().endswith("}loc") and el.text]
    if tag.endswith("sitemapindex"):
        for loc in locs:
            if len(urls) >= max_urls:
                break
            urls.extend(sitemap_urls(session, loc, timeout, max_urls-len(urls), seen))
    else:
        urls.extend(u for u in locs if clean_url(u))
    return urls[:max_urls]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/sites.json")
    ap.add_argument("--out", default="reports")
    args = ap.parse_args()
    with open(args.config, encoding="utf-8") as f:
        cfg = json.load(f)
    os.makedirs(args.out, exist_ok=True)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    rows = []
    site_summaries = []
    for site in cfg["sites"]:
        name, base = site["name"], site["base_url"].rstrip("/")
        parsed = urlparse(base)
        host = parsed.netloc
        session = requests.Session()
        session.headers.update({"User-Agent": cfg.get("user_agent", "SEO-ReadOnly-Audit/1.0")})
        timeout = int(cfg.get("request_timeout_seconds", 20))
        delay = float(cfg.get("delay_seconds", 0.4))
        robots_url = f"{parsed.scheme}://{host}/robots.txt"
        robots_r = get(session, robots_url, timeout)
        robots_status = "request_error" if isinstance(robots_r, Exception) else str(robots_r.status_code)
        sitemap_candidates = []
        if not isinstance(robots_r, Exception) and robots_r.status_code < 400:
            for line in robots_r.text.splitlines():
                if line.lower().startswith("sitemap:"):
                    sitemap_candidates.append(line.split(":", 1)[1].strip())
        sitemap_candidates.extend([f"{base}/sitemap.xml", f"{base}/sitemap_index.xml"])
        urls = []
        for sm in dict.fromkeys(sitemap_candidates):
            urls.extend(sitemap_urls(session, sm, timeout, int(cfg.get("max_urls_per_site", 100))))
            if len(set(urls)) >= int(cfg.get("max_urls_per_site", 100)):
                break
        urls = list(dict.fromkeys(u for u in urls if same_host(base, u)))[:int(cfg.get("max_urls_per_site", 100))]
        if not urls:
            urls = [base + "/"]
        # Keep a homepage first, then URLs discovered in the sitemap.
        homepage = base + "/"
        urls = list(dict.fromkeys([homepage] + urls))
        seen = set()
        title_counts, desc_counts = Counter(), Counter()
        site_rows = []
        for url in urls:
            if url in seen:
                continue
            seen.add(url)
            time.sleep(delay)
            response = get(session, url, timeout)
            row = {
                "site": name, "url": url, "status_code": "", "final_url": "",
                "title": "", "title_length": "", "meta_description": "",
                "description_length": "", "canonical": "", "h1": "",
                "robots_meta": "", "issues": ""
            }
            issues = []
            if isinstance(response, Exception):
                issues.append("request_error")
                row["issues"] = "; ".join(issues)
                rows.append(row); site_rows.append(row)
                continue
            row["status_code"] = response.status_code
            row["final_url"] = response.url
            ctype = response.headers.get("Content-Type", "").lower()
            if response.status_code >= 400:
                issues.append("http_error")
            if "text/html" not in ctype:
                issues.append("non_html_or_unknown_content_type")
                row["issues"] = "; ".join(issues)
                rows.append(row); site_rows.append(row)
                continue
            soup = BeautifulSoup(response.text, "html.parser")
            title = soup.title.get_text(" ", strip=True) if soup.title else ""
            desc_tag = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
            desc = (desc_tag.get("content") or "").strip() if desc_tag else ""
            can_tag = soup.find("link", rel=lambda v: v and "canonical" in [x.lower() for x in (v if isinstance(v,list) else [v])])
            canonical = (can_tag.get("href") or "").strip() if can_tag else ""
            if canonical:
                canonical = urljoin(response.url, canonical)
            h1s = [h.get_text(" ", strip=True) for h in soup.find_all("h1")]
            robots = soup.find("meta", attrs={"name": re.compile("^robots$", re.I)})
            robots_meta = (robots.get("content") or "").strip().lower() if robots else ""
            row.update({
                "title": title, "title_length": len(title),
                "meta_description": desc, "description_length": len(desc),
                "canonical": canonical, "h1": " | ".join(h1s[:3]),
                "robots_meta": robots_meta
            })
            if not title: issues.append("missing_title")
            elif len(title) > 60: issues.append("title_over_60_chars_review")
            if not desc: issues.append("missing_meta_description")
            elif len(desc) > 160: issues.append("description_over_160_chars_review")
            if not canonical: issues.append("missing_canonical_review")
            if not h1s: issues.append("missing_h1")
            elif len(h1s) > 1: issues.append("multiple_h1_review")
            if "noindex" in robots_meta: issues.append("noindex_meta")
            if response.url.rstrip("/") != url.rstrip("/"): issues.append("redirected_url")
            if canonical and not same_host(base, canonical): issues.append("cross_host_canonical_review")
            title_counts[title.lower()] += 1 if title else 0
            desc_counts[desc.lower()] += 1 if desc else 0
            row["issues"] = "; ".join(issues)
            rows.append(row); site_rows.append(row)
        # Duplicate metadata findings are flagged after all pages are processed.
        for row in site_rows:
            extra = []
            if row["title"] and title_counts[row["title"].lower()] > 1: extra.append("duplicate_title_review")
            if row["meta_description"] and desc_counts[row["meta_description"].lower()] > 1: extra.append("duplicate_description_review")
            if extra:
                row["issues"] = "; ".join(filter(None, [row["issues"], *extra]))
        issue_counts = Counter()
        for row in site_rows:
            for issue in filter(None, row["issues"].split("; ")):
                issue_counts[issue] += 1
        site_summaries.append({
            "site": name, "base_url": base, "robots_status": robots_status,
            "urls_checked": len(site_rows), "issue_counts": issue_counts,
        })
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    csv_path = os.path.join(args.out, f"seo-audit-{stamp}.csv")
    md_path = os.path.join(args.out, f"seo-audit-{stamp}.md")
    fieldnames = ["site","url","status_code","final_url","title","title_length","meta_description","description_length","canonical","h1","robots_meta","issues"]
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames); writer.writeheader(); writer.writerows(rows)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Technical SEO Audit\n\nGenerated: {now}\n\n")
        f.write("> Read-only checks. Length thresholds are review flags, not absolute ranking rules. Confirm each issue before changing a live page.\n\n")
        for s in site_summaries:
            f.write(f"## {s['site']}\n\n")
            f.write(f"- Website: {s['base_url']}\n- robots.txt HTTP status: {s['robots_status']}\n- URLs checked: {s['urls_checked']}\n\n")
            if s["issue_counts"]:
                f.write("| Finding | URL count |\n|---|---:|\n")
                for issue, count in s["issue_counts"].most_common():
                    f.write(f"| `{issue}` | {count} |\n")
            else:
                f.write("No findings were flagged by these basic checks.\n")
            f.write("\n")
        f.write("## Next-step notes\n\n")
        f.write("- Validate server errors and redirect chains before fixing.\n")
        f.write("- Confirm intended canonical/noindex behavior with the site's owner.\n")
        f.write("- Use Search Console data to prioritize pages and detect query cannibalization.\n")
        f.write("- This script does not inspect rendered JavaScript, Core Web Vitals field data, backlinks, rankings, or GBP data.\n")
    print(f"Created {csv_path} and {md_path}")
if __name__ == "__main__":
    main()
